This is an import from https://github.com/khanlou/Promise
license: MIT
